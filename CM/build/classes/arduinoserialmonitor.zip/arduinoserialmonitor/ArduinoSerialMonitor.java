package arduinoserialmonitor;

/** HowTo Install:
 * On JRE, copy:
 *  - file rxtxSerial.dll to %JDK%\jre\bin\rxtxSerial.dll;
 *  - file RXTXcomm.jar to %JDK%\jre\lib\ext\RXTXcomm.jar;
 * 
 * On the Java Project:
 *  - CM Project>Properties: BuildPath>Libraries>AddExternalJARs:
 *   %JDK%\jre\lib\ext\RXTXcomm.jar
 */
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
//import javax.comm.*; // for SUN's serial/parallel port libraries
import gnu.io.*; // for rxtxSerial library

public class ArduinoSerialMonitor implements WindowListener, ActionListener, Runnable, SerialPortEventListener {

    private static Vector<CommPortIdentifier> vectorSerialPortID = new Vector<CommPortIdentifier>();
    private static Enumeration portList;
    //private static CommPortIdentifier portID;
    private SerialPort serialPort;
    private Thread readThread;
    
    private InputStream inputStream;    
    private InputStreamReader is;
    private BufferedReader br;
    
    private OutputStream outputStream;
    private PrintWriter pw;
    private boolean outputBufferEmptyFlag = false;

    //Inicializar as variaveis para das interfaces
    private JFrame jframe = new JFrame("Shinning");
    private JComboBox jcbox = new JComboBox();
    private JLabel jlabel = new JLabel("Ports: ");
    private Container c = jframe.getContentPane();
    //private BulbLamp lamp = new BulbLamp("LampON.jpg", "LampOFF.jpg");
    private BulbLamp lamp = new BulbLamp("HandLampOk.jpg", "HandLamp.jpg");

    public static void main(String[] args) {
        Vector<String> vectorSerialPorts = new Vector<String>();
        boolean portFound = false;
        String defaultPort = "COM11";

        System.out.println("ArduinoSerialMonitor - main(): set default port to " + defaultPort);

        // Find available ports
        portList = CommPortIdentifier.getPortIdentifiers();

        while (portList.hasMoreElements()) {
            CommPortIdentifier port = (CommPortIdentifier) portList.nextElement();
            if (port.getPortType() == CommPortIdentifier.PORT_SERIAL) {
                //System.out.println("ArduinoSerialMonitor - main(): port found: " + port.getName());
                vectorSerialPortID.addElement(port);
                vectorSerialPorts.addElement(port.getName());
            }

            /*
            if (port.getPortType() == CommPortIdentifier.PORT_SERIAL) {
            portID = port;
            System.out.println("ArduinoSerialMonitor - main(): port found: " + portID.getName());
            portFound = true;
            }
             */
        }
        if (vectorSerialPorts.size() > 0) {
            ArduinoSerialMonitor monitor = new ArduinoSerialMonitor(vectorSerialPorts);
        }
    }

    //Construtor 
    public ArduinoSerialMonitor(Vector<String> vectorSerialPorts) {
        System.out.println("ArduinoSerialMonitor - ArduinoSerialMonitor(): ports found = " + vectorSerialPorts.size());

        //jcbox = new JComboBox();
        //jcbox.setSelectedIndex(jcbox.getItemCount()-1);
        jcbox.removeAllItems();
        vectorSerialPorts.add(0, "Select COM port...");
        for (String s : vectorSerialPorts) {
            jcbox.addItem(s);
        }

        c.add(BorderLayout.NORTH, jcbox);
        c.add(BorderLayout.CENTER, lamp);
        c.add(BorderLayout.SOUTH, jlabel);

        jcbox.addActionListener(this);
        jframe.addWindowListener(this);

        jframe.pack();
        jframe.setSize(400, 540);
        //int w = jcbox.getWidth();
        //int h = jcbox.getHeight() + lamp.getHeight() + jlabel.getHeight();
        //System.out.println("ArduinoSerialMonitor - ArduinoSerialMonitor(): width x hight = " + w + ", " + h);
        //jframe.setSize(w, h);
        jframe.setVisible(true);
        jframe.repaint();
    }

    public void run() {
    }

    public void actionPerformed(ActionEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
        JComboBox cb = (JComboBox) e.getSource();
        String port = (String) cb.getSelectedItem();
        int item = cb.getSelectedIndex();
        System.out.println("ArduinoSerialMonitor - actionPerformed(): port combo box selected item = " + item);

        if (item > 0) {
            // Get SerialPort
            CommPortIdentifier portid = vectorSerialPortID.elementAt(item - 1);
            System.out.println("ArduinoSerialMonitor - actionPerformed(): item = " + item + " portid = " + portid.getName());
            // Inicializa a porta serie
            try {
                serialPort = (SerialPort) portid.open("SimpleRead", 2000);

                // Set reader
                inputStream = serialPort.getInputStream();
                is = new InputStreamReader(this.inputStream);
                br = new BufferedReader(is);
                
                // Set writer
                outputStream = serialPort.getOutputStream();
                pw = new PrintWriter(outputStream);
                
                // Activate DATA_AVAILABLE notifier
                serialPort.notifyOnDataAvailable(true);
                // Set serial port parameters
                serialPort.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);

                // Handle events from serial port
                serialPort.addEventListener(this);

                // Inicia a leitura da thread
                //readThread = new Thread(this);
                //readThread.start();
            } catch (PortInUseException piue) {
                piue.printStackTrace();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            } catch (TooManyListenersException tmle) {
                tmle.printStackTrace();
            } catch (UnsupportedCommOperationException ucoe) {
                ucoe.printStackTrace();
            }
        }
    }

    public void serialEvent(SerialPortEvent event) {
        switch (event.getEventType()) {
            case SerialPortEvent.BI:
            case SerialPortEvent.OE:
            case SerialPortEvent.FE:
            case SerialPortEvent.PE:
            case SerialPortEvent.CD:
            case SerialPortEvent.CTS:
            case SerialPortEvent.DSR:
            case SerialPortEvent.RI:
            case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
                break;
            case SerialPortEvent.DATA_AVAILABLE:
                // Colocar no readBuffer a informacao recebida
                try {
                    // Leitura do comando H / L enviado pelo Arduino
                    //InputStreamReader is= new InputStreamReader(this.inputStream);
                    //BufferedReader br = new BufferedReader(is);
                    String result = br.readLine();
                    System.out.println("serialEvent(" + SerialPortEvent.DATA_AVAILABLE + "): result = " + result);

                    int charIndex = -1;
                    if (charIndex == -1) {
                        charIndex = result.indexOf('H');
                    }
                    if (charIndex == -1) {
                        charIndex = result.indexOf('L');
                    }
                    System.out.println("serialEvent(" + SerialPortEvent.DATA_AVAILABLE + "): charIndex = " + charIndex);
                    char c = result.charAt(charIndex);
                    System.out.println("serialEvent(" + SerialPortEvent.DATA_AVAILABLE + "): c = " + c);

                    if (c == 'H' || c == 'h') {
                        jlabel.setText("result = " + result);
                        jlabel.setForeground(Color.BLACK);
                        lamp.lampON();
                        //lamp.repaint();
                    } else if (c == 'L' || c == 'L') {
                        jlabel.setText("result = " + result);
                        jlabel.setForeground(Color.BLACK);
                        lamp.lampOFF();
                        //lamp.repaint();
                    }
                    this.jframe.repaint();
                    /*
                    byte[] readBuffer = new byte[256];
                    while (inputStream.available() > 0)
                    {
                    int numBytes = inputStream.read(readBuffer, 0, readBuffer.length);
                    }
                    // Imprimir a informacao
                    //Colocar a informacao numa string
                    String result = new String(readBuffer);
                    //Tirar os espacos finais da string
                    result = result.trim();
                    System.out.println("Read: " + result);

                    //Convercao da string para inteiro para fazer a troca das lampadas
                    int valor = Integer.parseInt(result);

                    if (valor < 270) {
                    jlabel.setText(valor + "<270");
                    jlabel.setForeground(Color.BLACK);
                    lamp.lampON();
                    lamp.repaint();
                    } else {
                    jlabel.setText(valor + ">270");
                    jlabel.setForeground(Color.BLACK);
                    lamp.lampOFF();
                    lamp.repaint();
                    }
                     */
                } catch (IOException e) {
                    //e.printStackTrace();
                    System.out.println(e.toString());
                }
                break;
        }
    }
    
    public void writeToSerialPort(String msg) {
        System.out.println("ArduinoSerialMonitor - writeToSerialPort(\"" + msg + "\"): to " + serialPort.getName());
        try {
            // write string to serial port
            outputStream.write(msg.getBytes());
            System.out.println("ArduinoSerialMonitor - writeToSerialPort(\"" + msg + "\"): finished sending to " + serialPort.getName());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String readFromSerialPort() {
        System.out.println("ArduinoSerialMonitor - readFromSerialPort(): from " + serialPort.getName());
        String comMsg = null;
        try {
            // Input porta serie
            InputStreamReader isr = new InputStreamReader(this.inputStream);
            BufferedReader br = new BufferedReader(isr);
            comMsg = br.readLine();
            br.close();
            System.out.println("ArduinoSerialMonitor - readFromSerialPort(): comMsg " + comMsg);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return comMsg;
    }

    public void windowOpened(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    public void windowClosing(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
        this.jframe.dispose();
        System.exit(0);
    }

    public void windowClosed(WindowEvent e) {
        this.jframe.dispose();
        System.exit(0);
    }

    public void windowIconified(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    public void windowDeiconified(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    public void windowActivated(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    public void windowDeactivated(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
    }
}
