SimpleSerial
by Ben Resner
benres@media.mit.edu

See index.html and comments in SimpleSerial.java