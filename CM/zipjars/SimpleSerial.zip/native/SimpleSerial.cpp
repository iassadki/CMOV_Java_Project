#include "simpleserial.h"

#include <windows.h>

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#include <stdio.h>

JNIEXPORT jint JNICALL Java_SimpleSerialNative__1openSerialPort
  (JNIEnv *env, jobject obj, jstring comPort, jint baud, jint dataBits, jint stopBits, jint parity)
{
	DCB				dcb;
	HANDLE			hCom;
	DWORD			dwError;
	BOOL			fSuccess;
	COMMTIMEOUTS	timeouts;
	const char		*buffer;

	buffer = env->GetStringUTFChars(comPort, NULL);

	hCom = CreateFile(buffer, 
		GENERIC_READ | GENERIC_WRITE,
		0,    // comm devices must be opened w/exclusive-access 
	    NULL, // no security attributes 
	    OPEN_EXISTING, // comm devices must use OPEN_EXISTING 
	    0,    // not overlapped I/O 
	
		NULL  // hTemplate must be NULL for comm devices     
		);

	env->ReleaseStringUTFChars(comPort, buffer);

	if (hCom == INVALID_HANDLE_VALUE) {    
		dwError = GetLastError();
		return 0;
    // handle error 
	}
	
	fSuccess = GetCommState(hCom, &dcb);
	if (!fSuccess) {    // Handle the error. 
		CloseHandle(hCom);
		return 0;

	}
/*
	dcb.fOutxCtsFlow = FALSE;
	dcb.fOutxDsrFlow = FALSE;
	dcb.fDtrControl = DTR_CONTROL_DISABLE;
	dcb.fDsrSensitivity = FALSE;
	dcb.fTXContinueOnXoff = FALSE;
	dcb.fOutX = FALSE;
	dcb.fInX = FALSE;
	dcb.fRtsControl = RTS_CONTROL_DISABLE;
	dcb.XonLim = 0;
	dcb.XoffLim = 0;
	dcb.ByteSize = 8;
*/

	dcb.BaudRate = baud;
	dcb.ByteSize = (unsigned char)dataBits;
	dcb.Parity = (unsigned char)parity;
	dcb.StopBits = (unsigned char)stopBits;
	fSuccess = SetCommState(hCom, &dcb);
	if (!fSuccess) {
		CloseHandle(hCom);
		return 0;
	}

/*
		0,	0,	0		waits forever
		0,	0,	1		20 ms delay
		0,	1,	0		waits forever
		0,	1,	1		waits forever
		1,	0,	0		waits forever
		1,	0,	1		20 ms delay
		1,  1,	0		waits forever
		1,	1,	1		waits forever
		10, 0,	10		20 ms delay
		10, 10, 10		waits forever (VERY SLOW)
		10, 1,	10		~500 ms
*/

	timeouts.ReadIntervalTimeout = MAXDWORD;
	timeouts.ReadTotalTimeoutMultiplier = 0;
	timeouts.ReadTotalTimeoutConstant = 0;
	timeouts.WriteTotalTimeoutConstant = 0;
	timeouts.WriteTotalTimeoutMultiplier = 0;

	fSuccess = SetCommTimeouts(hCom, &timeouts);
	if (!fSuccess) {
		CloseHandle(hCom);
		return 0;
	}

	FlushFileBuffers(hCom);
	PurgeComm(hCom, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);

	return (long)hCom;
}

/*
 * Class:     SimpleSerial
 * Method:    _readSerialPort
 * Signature: (I)[B
 */
JNIEXPORT jbyteArray JNICALL Java_SimpleSerialNative__1readSerialPort
  (JNIEnv *env, jobject obj, jint port)
{
	DWORD		numRead;
	char		buffer[512];		// this should be large enough;

	ReadFile((void*)port, buffer, 512, &numRead, NULL);

//	printf("native sez read %d", (int)numRead);
	
	jbyteArray		byteArray = env->NewByteArray(numRead);	

	env->SetByteArrayRegion(byteArray, 0, numRead, (signed char*)buffer);

	return byteArray;
}

/*
 * Class:     SimpleSerial
 * Method:    _writeSerialPort
 * Signature: (I[B)I
 */
JNIEXPORT jint JNICALL Java_SimpleSerialNative__1writeSerialPort
  (JNIEnv *env, jobject obj, jint port, jbyteArray bytes)
{
	DWORD			numWritten;
	int				size;
	signed char			*buffer;

	size = env->GetArrayLength(bytes);

	if (size == 0) {		// nothing to write
		return 0;
	}

	buffer = env->GetByteArrayElements(bytes, NULL);

	WriteFile((void*)port, buffer, size, &numWritten, NULL);
	FlushFileBuffers((void*)port);

	env->ReleaseByteArrayElements(bytes, buffer, JNI_ABORT);	

	return numWritten;
}

/*
 * Class:     SimpleSerial
 * Method:    _writeSerialPortByte
 * Signature: (IB)I
 */

JNIEXPORT jint JNICALL Java_SimpleSerialNative__1writeSerialPortByte
  (JNIEnv *env, jobject obj, jint port, jbyte byte)
{
	DWORD		numWritten;

	WriteFile((void*)port, &byte, 1, &numWritten, NULL);
	FlushFileBuffers((void*)port);

	return numWritten;
}

/*
 * Class:     SimpleSerial
 * Method:    _closeSerialPort
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_SimpleSerialNative__1closeSerialPort
  (JNIEnv *, jobject, jint port)
{
	if (port) CloseHandle((void*)port);
}
