If you want to try to build a standalone application, you'll need some of the
tools in this folder.  It worked for me in VisualCafe 3.0, but stopped
working in VisualCafe 4.0.

If you rebuild the native DLL, and you want to rebuild SimpleSerialEXE.exe
you must rebuild SimpleSerial.lib.  The .lib file MSVC++ produces is in COFF 
format, which isn't understood by the Java compiler.

1.  Delete SimpleSerialNative.lib.

2.  Run implib.exe on SimpleSerialNative.dll.  This program creates SimpleSerialNative.lib 
file based on the .dll

3.  Run the created SimpleSerial.lib through Coff2omf.exe to convert it from COFF to OMF
format.  NOTE:  If you try and do this with the lib file created by the MS compiler, it
will fail.

4.  Copy the .lib file to the SimpleSerial directory