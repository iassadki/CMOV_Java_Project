package edu.ufp.cm.arduinoserialmonitor.usingjserialcomm;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.fazecast.jSerialComm.*;
import edu.ufp.cm.arduinoserialmonitor.BulbLamp;

/**
 * The jSerialComm is a Java library designed to provide a platform-independent way to access standard serial ports
 * without requiring external libraries, native code, or any other tools (automatically uses correct native library
 * based on current architecture).
 *
 * It is an alternative to RxTx and the (deprecated) Java Communications API, with support for timeouts and ability to
 * open multiple ports simultaneously (cf. http://fazecast.github.io/jSerialComm/).
 *
 * Copy jSerialComm.jar file into project lib directory and add it into project.
 *
 * For examples check:
 *  https://github.com/Fazecast/jSerialComm/wiki/Usage-Examples
 * 
 */
public class ArduinoSerialMonitorJSerialComm implements WindowListener, ActionListener, SerialPortDataListener {

    private static final ArrayList<SerialPort> vectorAvailableSerialPorts= new ArrayList<>();

    private static Enumeration portList;
    private SerialPort serialPort;

    private InputStream inputStream;
    private InputStreamReader is;
    private BufferedReader br;

    private OutputStream outputStream;
    private PrintWriter pw;

    //Inicializar variaveis da gui
    private final JFrame jframe = new JFrame("Shinning");
    private final JComboBox<String> jcbox = new JComboBox<String>();
    private final JLabel jlabel = new JLabel("Ports: ");
    private final Container c = jframe.getContentPane();

    private final BulbLamp lamp = new BulbLamp("res/HandLampOk.jpg", "res/HandLamp.jpg");

    public static void main(String[] args) {
        SerialPort[] serialPorts = SerialPort.getCommPorts();

        System.out.println("ArduinoSerialMonitorJSerialComm - main(): serialPorts.length = " + serialPorts.length);
        for (int i=0; i < serialPorts.length; i++) {
            System.out.println("ArduinoSerialMonitorJSerialComm - main(): serialPorts.toString() = " + serialPorts[i].toString());
            vectorAvailableSerialPorts.add(serialPorts[i]);
        }

        if (serialPorts.length > 0) {
            ArduinoSerialMonitorJSerialComm monitor = new ArduinoSerialMonitorJSerialComm(serialPorts);
        }
    }

    //Construtor
    public ArduinoSerialMonitorJSerialComm(SerialPort[] serialPorts) {
        System.out.println("ArduinoSerialMonitorJSerialComm - ArduinoSerialMonitorJSerialComm(): ports received = " + serialPorts.length);
        jcbox.removeAllItems();
        jcbox.addItem("Select COM port...");
        for (SerialPort port : serialPorts) {
            if (port!=null && jcbox!=null){
                jcbox.addItem(port.toString());
            }
        }

        c.add(BorderLayout.NORTH, jcbox);
        c.add(BorderLayout.CENTER, lamp);
        c.add(BorderLayout.SOUTH, jlabel);

        //Set gui listeners...
        jcbox.addActionListener(this);
        jframe.addWindowListener(this);

        jframe.pack();
        jframe.setSize(400, 540);
        jframe.setVisible(true);
        jframe.repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
        JComboBox cb = (JComboBox) e.getSource();
        String port = (String) cb.getSelectedItem();
        int item = cb.getSelectedIndex();
        System.out.println("ArduinoSerialMonitorJSerialComm - actionPerformed(): port combo box selected item = " + item);

        if (item > 0) {
            // Get selected SerialPort
            serialPort = vectorAvailableSerialPorts.get(item - 1);
            System.out.println("ArduinoSerialMonitorJSerialComm - actionPerformed(): item = " + item + " serialPort = " + serialPort.toString());
            // Inicializa a porta serie
            try {
                //Open serial port
                serialPort.openPort();

                // Set reader
                inputStream = serialPort.getInputStream();
                br = new BufferedReader(new InputStreamReader(this.inputStream));

                // Set writer
                outputStream = serialPort.getOutputStream();
                pw = new PrintWriter(outputStream);

                // Set serial port parameters
                serialPort.setComPortParameters(9600, 8, SerialPort.ONE_STOP_BIT, SerialPort.NO_PARITY);
                //Set Read Time outs
                //serialPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING,1000,0);

                // Handle data events from serial port
                serialPort.addDataListener(this);
                System.out.println("actionPerformed(): port description " + serialPort.getPortDescription());
            } catch (SerialPortInvalidPortException spipe) {
                spipe.printStackTrace();
            }
        }
    }

    @Override
    //public int getListeningEvents() { return SerialPort.LISTENING_EVENT_DATA_AVAILABLE; }
    public int getListeningEvents() { return SerialPort.LISTENING_EVENT_DATA_RECEIVED; }

    @Override
    public void serialEvent(SerialPortEvent event) {
        System.out.println("serialEvent(): event.getEventType() = " + event.getEventType());
        /*
        if (event.getEventType() != SerialPort.LISTENING_EVENT_DATA_AVAILABLE) return;
        byte[] newData=new byte[serialPort.bytesAvailable()];
        int numRead = serialPort.readBytes(newData, newData.length);
        */
        byte[] receivedSerialData = event.getReceivedData();
        int numRead = receivedSerialData.length;
        System.out.println("serialEvent(): Read " + numRead + " bytes.");

        String result = new String(receivedSerialData);
        //Clear tail spaces
        result = result.trim();
        System.out.println("serialEvent(): Data read = |" + result + "|");

        //Parse Light Sensor value sent via serial port,
        parseLightSensorInput(result);

        this.jframe.repaint();
    }
    
    private void parseLightSensorInput(String result) {
        //Parse Light Sensor value sent via serial port,
        //assuming message is something like: "light=700;"
        //We need to extract the number between '=' and ';' chars
        int equalIndex = result.indexOf("=")+1;
        int dotcommaIndex = result.indexOf(";");
        System.out.println("parseLightSensorInput(): equalIndex = " + equalIndex);
        System.out.println("parseLightSensorInput(): commaIndex = " + dotcommaIndex);

        //If did not received a correct sensor value (number format)
        if (equalIndex<=0 || dotcommaIndex<=0) {
            System.out.println("parseLightSensorInput(): something went wrong with received sensor value format!!!\n");
            return;
        }
        String sensorValueStr = result.substring(equalIndex, dotcommaIndex);
        System.out.println("parseLightSensorInput(): sensorValueStr = |" + sensorValueStr + "|");
        int sensorValue=0;
        try {
            sensorValue=Integer.parseInt(sensorValueStr);
            System.out.println("parseLightSensorInput(): sensorValue = |" + sensorValue + "|");
        } catch (NumberFormatException nfe){
            System.out.println("parseLightSensorInput(): NumberFormatException = " + nfe.toString());
        }
        jlabel.setText("Received serial string: |" + result + "|");
        jlabel.setForeground(Color.BLACK);
        if (sensorValue<500) {
            lamp.lampON();
        } else {
            lamp.lampOFF();
        }
        //lamp.repaint();
        System.out.println("");
    }
    
    private void parseHorLInput(String msg) {
        /*
        // Leitura do comando H / L enviado pelo Arduino
        int charIndex = -1;
        if (charIndex == -1) {
            charIndex = result.indexOf('H');
        }
        if (charIndex == -1) {
            charIndex = result.indexOf('L');
        }

        System.out.println("serialEvent(" + SerialPortEvent.DATA_AVAILABLE + "): charIndex = " + charIndex);
        char c = result.charAt(charIndex);
        System.out.println("serialEvent(" + SerialPortEvent.DATA_AVAILABLE + "): c = " + c);

        if (c == 'H' || c == 'h') {
            jlabel.setText("result = " + result);
            jlabel.setForeground(Color.BLACK);
            lamp.lampON();
            //lamp.repaint();
        } else if (c == 'L' || c == 'L') {
            jlabel.setText("result = " + result);
            jlabel.setForeground(Color.BLACK);
            lamp.lampOFF();
            //lamp.repaint();
        }
        */
    }
    
    public void writeToSerialPort(String msg) {
        System.out.println("ArduinoSerialMonitorJSerialComm - writeToSerialPort(\"" + msg + "\"): to " + serialPort.toString());
        try {
            // write string to serial port
            outputStream.write(msg.getBytes());
            System.out.println("ArduinoSerialMonitorJSerialComm - writeToSerialPort(\"" + msg + "\"): finished sending to " + serialPort.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String readFromSerialPort() {
        System.out.println("ArduinoSerialMonitorJSerialComm - readFromSerialPort(): from " + serialPort.toString());
        String comMsg = null;
        try {
            // Input porta serie
            InputStreamReader isr = new InputStreamReader(this.inputStream);
            BufferedReader braux = new BufferedReader(isr);
            comMsg = braux.readLine();
            br.close();
            System.out.println("ArduinoSerialMonitorJSerialComm - readFromSerialPort(): comMsg " + comMsg);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return comMsg;
    }

    @Override
    public void windowOpened(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void windowClosing(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
        this.jframe.dispose();
        System.exit(0);
    }

    @Override
    public void windowClosed(WindowEvent e) {
        this.jframe.dispose();
        System.exit(0);
    }

    @Override
    public void windowIconified(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void windowActivated(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
    }
}


